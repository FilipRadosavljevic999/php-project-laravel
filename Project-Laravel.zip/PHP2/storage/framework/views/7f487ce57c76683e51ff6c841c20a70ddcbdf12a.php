
<section id="copyright">
    <span>Copyright Filip Radosavljevic.</span>
</section>

<?php /**PATH C:\xampp\htdocs\PHP2\resources\views/fixed/footer.blade.php ENDPATH**/ ?>