<?php $__env->startSection('content'); ?>
    <section class="main-content">

        <div class="row">
            <div class="span9">
                <div width="100%">
                    <ul class="thumbnails listing-products">

                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php echo $__env->make('partial.partialProduct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <h2>No products.</h2>
                            <?php endif; ?>
                    </ul>


                </div>
            </div>
            <div class="span3 col">
                <br/>
                <div class="block">
                    <form action="/" method="GET">

                        <div class="row">
                            <h3>Pretraga</h3>
                            <div class="col-md-2">
                                <input type="text" name="rec" placeholder="Unesi slova"  class="form-control"
                                       <?php if($rec==""): ?> value="<?php echo e($rec); ?>"<?php endif; ?>>
                            </div>
                            <div class="col-md-2">
                                <input type="submit" placeholder="Pretrazi" value="Pretrazi" class="btn btn-primary">
                            </div>
                        </div>
                    </form>
                </div>


            </div>
        </div>
        </div>
        <div class="row center ">

                <?php echo e($products->links()); ?>





        </div>



    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PHP2\resources\views/pages/product.blade.php ENDPATH**/ ?>