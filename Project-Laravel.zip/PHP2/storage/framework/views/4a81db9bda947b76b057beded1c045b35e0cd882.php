<section class="navbar main-menu">
    <div class="navbar-inner main-menu">

        <nav id="menu" class="pull-right">

            <ul>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(session()->has('korisnik')): ?>
                        <?php if(session()->get('korisnik')->uloga=='admin'): ?>
                            <?php if($link->iduloga==3): ?>
                                <li class="nav-item <?php if(request()->routeIs($link->putanja)): ?> active <?php endif; ?>">
                                    <a href="<?php echo e(route($link->putanja)); ?>"><?php echo e($link->naziv); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($link->iduloga==2): ?>

                                <?php if($link->iduloga==2): ?>
                                    <li class="nav-item <?php if(request()->routeIs($link->putanja)): ?> active <?php endif; ?>">
                                        <a href="<?php echo e(route($link->putanja)); ?>"><?php echo e($link->naziv); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($link->iduloga==1): ?>
                            <li class="nav-item <?php if(request()->routeIs($link->putanja)): ?> active <?php endif; ?>">
                                <a href="<?php echo e(route($link->putanja)); ?>"><?php echo e($link->naziv); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




            </ul>
        </nav>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\PHP2\resources\views/fixed/menu.blade.php ENDPATH**/ ?>