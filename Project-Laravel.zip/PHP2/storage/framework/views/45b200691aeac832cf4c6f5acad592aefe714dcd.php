<?php $__env->startSection('content'); ?>
    <section class="main-content">
        <div class="row" style="height: 700px;">

            <div class="span9">

                <div class="row">
                    <?php $__currentLoopData = $owner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="span4">
                            <img  width="100%"alt="" src="<?php echo e(asset('assets/img/'.$a->slika)); ?>">

                        </div>
                        <div class="span5">
                            <p><?php echo e($a->ime); ?></p>

                        </div>

                        <div class="span5">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">


                    </div>
                </div>

            </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PHP2\resources\views/pages/owner.blade.php ENDPATH**/ ?>