<?php $__env->startSection('content'); ?>
    <section class="main-content">
        <div class="row" style=" margin-top: 50px;">
            <div class="span9">
                <?php $__currentLoopData = $oneproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">

                        <div class="span4">
                            <img  width="100%"alt="" src="<?php echo e(asset('/assets/img/'.$p->Slika)); ?>">

                        </div>
                        <div class="span5">
                            <address>
                                <strong>Nazvi Artikla</strong> <span><?php echo e($p->NazivArtikla); ?></span><br>
                                <strong>Vodootpornost:</strong> <span><?php echo e($p->VodoOtp); ?></span><br>
                                <strong>Narukvica:</strong> <span><?php echo e($p->NazvNarukvice); ?></span><br>
                                <strong>Mehanizam:</strong> <span><?php echo e($p->MehanizamNaziv); ?></span><br>
                                <strong>Pol:</strong> <span><?php echo e($p->Pol); ?></span><br>
                                <strong>Precnik:</strong> <span><?php echo e($p->Precnik); ?></span><br>
                                <strong>Kolekcija:</strong> <span><?php echo e($p->Vrsta); ?></span><br>
                            </address>
                            <h4><strong>Cena: <?php echo e($p->cena); ?> din.</strong></h4>
                        </div>

                        <div class="span5">
                            <?php if(session()->has('korisnik')): ?>
                                <form method="post" action="<?php echo e(route('order',["id" => $p->ID])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <fieldset>
                                        <div class="clearfix">
                                            <label for="name"><span>Ime:</span></label>
                                            <div class="input">
                                                <input tabindex="1" size="18" id="name" name="ime" type="text" value="" class="input-xlarge" placeholder="Unesi ime">
                                            </div>
                                        </div>

                                        <div class="clearfix">
                                            <label for="email"><span>Prezime:</span></label>
                                            <div class="input">
                                                <input tabindex="2" size="25" id="email" name="prezime" type="text" value="" class="input-xlarge" placeholder="Unesi Prezime">
                                            </div>
                                        </div>

                                        <div class="clearfix">
                                            <label for="message"><span>Adresa:</span></label>
                                            <div class="input">
                                                <input tabindex="2" size="25" id="email" name="adresa" type="text" value="" class="input-xlarge" placeholder="Unesi Adresu">
                                            </div>
                                        </div>
                                        <div class="clearfix">
                                            <label for="message"><span>Broj Telefona:</span></label>
                                            <div class="input">
                                                <input tabindex="2" size="25" id="email" name="brojtel" type="text" value="" class="input-xlarge" placeholder="Unesi broj telefona">
                                            </div>
                                        </div>

                                        <div class="actions">
                                            <button tabindex="3" type="submit" class="btn btn-inverse">Poruci</button>
                                        </div>
                                        <div class="row center">
                                            <?php if($errors->any()): ?>
                                                <div class="alert alert-danger">
                                                    <ul>
                                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><?php echo e($error); ?></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                                <?php if(session()->has('Success')): ?>
                                                    <h4><?php echo e(session()->get('Success')); ?></h4>

                                                <?php endif; ?>
                                        </div>
                                    </fieldset>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="row">


                </div>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PHP2\resources\views/pages/oneproduct.blade.php ENDPATH**/ ?>