<script src="<?php echo e(asset("asset/themes/js/common.js")); ?>"></script>
<script src="<?php echo e(asset("assets/themes/js/jquery.flexslider-min.js")); ?>"></script>
<script type="text/javascript">
    $(function() {
        $(document).ready(function() {
            $('.flexslider').flexslider({
                animation: "fade",
                slideshowSpeed: 4000,
                animationSpeed: 600,
                controlNav: false,
                directionNav: true,
                controlsContainer: ".flex-container" // the container that holds the flexslider
            });
        });
    });
</script>
<?php if(!empty(session('user'))): ?>

<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\PHP2\resources\views/fixed/script.blade.php ENDPATH**/ ?>