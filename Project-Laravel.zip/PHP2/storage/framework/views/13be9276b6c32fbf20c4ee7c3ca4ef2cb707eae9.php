<head>
    <meta charset="utf-8">
    <title>Bootstrap E-commerce Templates</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
    <!-- bootstrap -->
    <link href="<?php echo e(asset("assets/bootstrap/css/bootstrap.min.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("assets/bootstrap/css/bootstrap-responsive.min.css")); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('assets/themes/css/bootstrappage.css')); ?>" rel="stylesheet"/>

    <!-- global styles -->
    <link href="<?php echo e(asset("assets/themes/css/flexslider.css")); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset("assets/themes/css/main.css")); ?>" rel="stylesheet"/>

    <!-- scripts -->
    <script src="<?php echo e(asset("assets/themes/js/jquery-1.7.2.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/bootstrap/js/bootstrap.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/themes/js/superfish.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/themes/js/jquery.scrolltotop.js")); ?>"></script>
<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <script src="<?php echo e(asset("assets/js/respond.min.js")); ?>"></script>
    <![endif]-->
</head>
<?php /**PATH C:\xampp\htdocs\PHP2\resources\views/fixed/head.blade.php ENDPATH**/ ?>