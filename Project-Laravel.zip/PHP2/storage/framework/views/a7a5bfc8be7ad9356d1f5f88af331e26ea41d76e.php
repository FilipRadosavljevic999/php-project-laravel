<?php $__env->startSection('content'); ?>
    <section class="main-content">
        <div class="row">
            <div class="span9 center" >
                <?php $__currentLoopData = $proizvod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form action="<?php echo e(route("eProduct",["id"=>$p->ID])); ?>" method="POST" class="form-stacked" style="margin-top: 50px;">
                    <?php echo csrf_field(); ?>


                        <div class="control-group" >
                            <label class="control-label">Naziv</label>
                            <div class="controls">
                                <input type="text" style="width: 30%" placeholder=" Izmeni Naziv" name="naziv" value="<?php echo e($p->NazivArtikla); ?>" class="input-xlarge">
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Cena:</label>
                            <div class="controls">
                                <input type="text" style="width: 30%" placeholder="Izmeni Cenu" value='<?php echo e($p->cena); ?>'name="cena" class="input-xlarge">
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Vodootpornost:</label>
                            <div class="controls">
                                <input type="text" style="width: 30%" placeholder="Izmeni Vodootpornost" value='<?php echo e($p->VodoOtp); ?>'name="vodootpornost" class="input-xlarge">
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Narukvica:</label>
                            <div class="controls">

                                <select name="narukvica" style="width:30%;">
                                    <?php $__currentLoopData = $narukvica; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option  value="<?php echo e($n->idnarukvica); ?>"><?php echo e($n->naziv); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Mehanizmi:</label>
                            <div class="controls">

                                <select name="mehanizmi"class="input-xlarge" style="width: 30%" id="exampleFormControlSelect1">
                                    <?php $__currentLoopData = $mehanizam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($m->idmehanizam); ?>"><?php echo e($m->naziv); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Pol:</label>
                            <div class="controls">

                                <select name="pol"class="input-xlarge" style="width: 30%" id="exampleFormControlSelect1">
                                    <?php $__currentLoopData = $pol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pl->idpol); ?>"><?php echo e($pl->nazivpola); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Precnik:</label>
                            <div class="controls">

                                <select name="precnik"class="input-xlarge" style="width: 30%"style="width: 30%" id="exampleFormControlSelect1">
                                    <?php $__currentLoopData = $precnik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pr->idprecnik); ?>"><?php echo e($pr->velicina); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="control-group">

                            <label class="control-label">Vrsta:</label>
                            <div class="controls">

                                <select name="vrsta"class="input-xlarge" style="width: 30%" id="exampleFormControlSelect1">
                                    <?php $__currentLoopData = $vrsta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($v->idvrsta); ?>"><?php echo e($v->vrstanaziv); ?>}</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="control-group">

                            <div class="controls">
                                <input type="hidden"  placeholder="Izmeni Naziv" name="id" value="<?php echo e($p->ID); ?>" class="input-xlarge">
                            </div>
                        </div>
                        <div class="actions"><input tabindex="9" class="btn btn-inverse large" type="submit" value="Izmeni Artikl"></div>
                        <div class="control-group">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('uspelo')): ?>
                                <p><?php echo e(session()->get('uspelo')); ?></p>

                            <?php endif; ?>

                        </div>
                </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PHP2\resources\views/pages/editProduct.blade.php ENDPATH**/ ?>