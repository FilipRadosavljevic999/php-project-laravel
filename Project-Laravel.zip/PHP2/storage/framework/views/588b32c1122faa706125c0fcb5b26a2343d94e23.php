<?php $__env->startSection('content'); ?>
    <section class="main-content">
        <div class="row">
            <div class="span9 center">
                <h2 class="title "><span class="text"><strong>Proizvodi</strong></span></h2>
                <table class="table table-striped table-bordered" style="border: 1px solid #0e0e0e">
                    <thead>
                    <tr>
                        <th>Redni broj</th>
                        <th>Slika</th>
                        <th>Naziv</th>
                        <th>Cena</th>
                        <th>Obrisi</th>
                        <th>Izmeni</th>
                        <th>Dodaj</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php
                        $br=1;
                    ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><?php echo e($br++); ?></td>
                            <td width="50%"  ><a href="<?php echo e(route('oneproduct',["id"=>$p->ID])); ?>" width="100%" height="70px" >
                                    <img alt="" width="50%" height="50px" src="<?php echo e(asset("assets/img/".$p->Slika)); ?>">
                                </a></td>
                            <td><?php echo e($p->NazivArtikla); ?></td>
                            <td><?php echo e($p->cena); ?> din</td>
                            <td><a href="<?php echo e(route("deleteProduct",["id"=>$p->ID])); ?>">Obrisi Proizvod</a></td>
                            <td><a href="<?php echo e(route("editProduct",["id"=>$p->ID])); ?>">Izmeni Proizvod</a></td>
                             <td><a href="<?php echo e(route("showAddProduct")); ?>">Dodaj Proizvod</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td></td>
                    </tr>
                    </tbody>
                </table>


            </div>
            <div class="span3 col">

            </div>
        </div>
        <div class="row">

            <div class="span10 center">
                <h2 class="title "><span class="text"><strong>Korisnici</strong></span></h2>
                <table class="table table-striped table-bordered" width="100%" style="border: 1px solid #0e0e0e">
                    <thead>
                    <tr>
                        <th >Redni broj</th>
                        <th>Ime</th>
                        <th>Prezime</th>
                        <th>Email</th>
                        <th>Obrisi</th>


                    </tr>
                    </thead>
                    <tbody>
                    <?php
                        $br=1;
                    ?>

                    <?php $__currentLoopData = $korisnici; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="border: 1px solid #0e0e0e">

                            <td><?php echo e($br++); ?></td>
                            <td width="50%"  ><?php echo e($k->ime); ?></td>
                            <td><?php echo e($k->prezime); ?></td>
                            <td><?php echo e($k->email); ?> </td>
                            <td><a href="<?php echo e(route("removeUser",['id'=>$k->idkorisnik])); ?>">Obrisi Korisnika</a></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td></td>
                    </tr>
                    </tbody>
                </table>


            </div>
            <div class="span3 col">

            </div>
        </div>
        <div class="row">

            <div class="span10 center">
                <h2 class="title "><span class="text"><strong>Porudzbine</strong></span></h2>

                <table class="table table-striped table-bordered" width="100%" style="border: 1px solid #0e0e0e">
                    <thead>
                    <tr>
                        <th>Redni broj</th>
                        <th>Ime</th>
                        <th>Prezime</th>
                        <th>Adresa</th>
                        <th>Broj Telefona</th>
                        <th>Obrisi Porudzbinu</th>


                    </tr>
                    </thead>
                    <tbody>
                    <?php
                        $br=1;
                    ?>
                    <?php $__currentLoopData = $porudzbina; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><?php echo e($br++); ?></td>
                            <td width="50%"  ><?php echo e($pr->ime); ?></td>
                            <td><?php echo e($pr->prezime); ?></td>
                            <td><?php echo e($pr->adresa); ?> </td>
                            <td><?php echo e($pr->brojtelefona); ?> din</td>
                            <td><a href="<?php echo e(route("deleteOrder",["id"=>$pr->idporudzbina])); ?>">Obrisi Porudzbinu</a></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td></td>
                    </tr>
                    </tbody>
                </table>


            </div>
            <div class="span3 col">

            </div>
        </div>
         <div class="row">

            <div class="span10 center">
                <h2 class="title "><span class="text"><strong>Poruke</strong></span></h2>
                <table class="table table-striped   table-bordered" width="100%" style="border: 1px solid #0e0e0e">
                    <thead>
                    <tr>
                        <th>Redni Br.</th>
                        <th>Email</th>
                        <th>Poruka</th>
                        <th>Obrisi poruku</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                        $br=1;
                    ?>

                    <?php $__currentLoopData = $poruke; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($br++); ?></td>
                            <td><?php echo e($pe->email); ?></td>
                            <td><?php echo e($pe->poruka); ?> </td>
                            <td><?php echo e($pe->poruka); ?> </td>
                            <td><a href="<?php echo e(route('removeMessage',['id'=>$pe->idPoruke])); ?>">Obrisi poruku</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td></td>
                    </tr>
                    </tbody>
                </table>


            </div>
            <div class="span3 col">

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PHP2\resources\views/pages/admin.blade.php ENDPATH**/ ?>