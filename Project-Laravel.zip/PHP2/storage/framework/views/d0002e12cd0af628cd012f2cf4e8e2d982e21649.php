<?php $__env->startSection("content"); ?>
    <section class="main-content">
        <div class="row" style="height: 700px;">
            <div class="span5">

            </div>
            <div class="span7">

                <form action="<?php echo e(route('send')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="clearfix">
                        <label for="message"><span>Poruka:</span></label>
                        <div class="input">
                            <textarea tabindex="3" class="input-xlarge" id="message" name="poruka" rows="7" placeholder="Poruka"></textarea>
                        </div>
                    </div>

                    <div class="actions">
                        <button tabindex="3" type="submit" class="btn btn-inverse">Posalji poruku</button>
                    </div>
                    <div class="clearfix">
                        <?php if(session()->has('Poslata')): ?>
                            <p><?php echo e(session()->get('Poslata')); ?></p>
                        <?php endif; ?>
                    </div>

                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PHP2\resources\views/pages/contact.blade.php ENDPATH**/ ?>