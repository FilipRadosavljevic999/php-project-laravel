<li class="span3">
    <div class="product-box">
        <span class="sale_tag"></span>

        <div width="100%"><img width="100%" alt="" src="<?php echo e(asset("assets/img/".$p->Slika)); ?>"></div><br/>
        <a href="<?php echo e(route('oneproduct', ["id" => $p->ID])); ?>" class="title"><?php echo e($p->NazivArtikla); ?></a><br/>

        <p class="price">$<?php echo e($p->cena); ?></p>
    </div>
</li>
<?php /**PATH C:\xampp\htdocs\PHP2\resources\views/partial/partialProduct.blade.php ENDPATH**/ ?>