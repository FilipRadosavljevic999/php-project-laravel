<script src="{{asset("asset/themes/js/common.js")}}"></script>
<script src="{{asset("assets/themes/js/jquery.flexslider-min.js")}}"></script>
<script type="text/javascript">
    $(function() {
        $(document).ready(function() {
            $('.flexslider').flexslider({
                animation: "fade",
                slideshowSpeed: 4000,
                animationSpeed: 600,
                controlNav: false,
                directionNav: true,
                controlsContainer: ".flex-container" // the container that holds the flexslider
            });
        });
    });
</script>
@if (!empty(session('user')))

@endif
