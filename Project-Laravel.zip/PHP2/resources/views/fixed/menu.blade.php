<section class="navbar main-menu">
    <div class="navbar-inner main-menu">

        <nav id="menu" class="pull-right">

            <ul>
                @foreach($data as $link)
                    @if(session()->has('korisnik'))
                        @if(session()->get('korisnik')->uloga=='admin')
                            @if($link->iduloga==3)
                                <li class="nav-item @if(request()->routeIs($link->putanja)) active @endif">
                                    <a href="{{route($link->putanja)}}">{{$link->naziv}}</a>
                                </li>
                            @endif
                        @else
                            @if($link->iduloga==2)

                                @if($link->iduloga==2)
                                    <li class="nav-item @if(request()->routeIs($link->putanja)) active @endif">
                                        <a href="{{route($link->putanja)}}">{{$link->naziv}}</a>
                                    </li>
                                @endif
                            @endif
                        @endif
                    @else
                        @if($link->iduloga==1)
                            <li class="nav-item @if(request()->routeIs($link->putanja)) active @endif">
                                <a href="{{route($link->putanja)}}">{{$link->naziv}}</a>
                            </li>
                        @endif
                    @endif

                @endforeach




            </ul>
        </nav>
    </div>
</section>
