<li class="span3">
    <div class="product-box">
        <span class="sale_tag"></span>

        <div width="100%"><img width="100%" alt="" src="{{asset("assets/img/".$p->Slika)}}"></div><br/>
        <a href="{{ route('oneproduct', ["id" => $p->ID]) }}" class="title">{{$p->NazivArtikla}}</a><br/>

        <p class="price">${{$p->cena}}</p>
    </div>
</li>
