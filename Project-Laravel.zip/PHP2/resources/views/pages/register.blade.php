@extends("layout.layout")
@section("content")
    <section class="main-content">
        <div class="row" style="">
            <div class="span5" style="height: 500px;">
                <h4 class="title"><span class="text"><strong>Registracija</strong> </span></h4>
                <form action="{{route('register')}}" method="post" style="height: 500px";>
                    @csrf
                    <fieldset  style="height: 500px">
                        <div class="control-group center">
                            <label class="control-label center">Unesi Ime</label>
                            <div class="controls">
                                <input type="text" placeholder="Unesi ime" name='ime' id="ime" style="width: 50%;" class="form-control center form-control-lg ">
                            </div>
                        </div>
                        <div class="control-group center">
                            <label class="control-label center">Unesi Prezime</label>
                            <div class="controls">
                                <input type="text" placeholder="Unesi prezime" id="prezime"  style="width: 50%;"name="prezime" class="form-control center form-control-lg">
                            </div>
                        </div>
                        <div class="control-group center">
                            <label class="control-label center">Unesi Email</label>
                            <div class="controls">
                                <input type="text" placeholder="Unesi Email" id="email" style="width: 50%;" name="email" class="form-control center form-control-lg">
                            </div>
                        </div>
                        <div class="control-group center">
                            <label class="col-sm">Unesi Sifru</label>
                            <div class="controls">
                                <input type="password" placeholder="Unesi sifru" id="sifra" style="width: 50%; " name="sifra" class="form-control form-control-lg center" >
                            </div>
                        </div>
                        <div class="control-group center">
                            <input tabindex="3" class="btn btn-inverse large center" type="submit" value="Registruj se">
                            <hr>

                        </div>

                    </fieldset>
                </form>
            </div>


            <div class="span7">
                <h4 class="title"><span class="text"><strong>Uloguj se</strong> </span></h4>
                <form action="{{route("login")}}" method="POST" class="form-stacked">
                    @csrf
                    <fieldset>
                        <div class="control-group">
                            <label class="control-label">Email</label>
                            <div class="controls">
                                <input type="text" placeholder="Unesi Email" name="email" class="input-xlarge">
                            </div>
                        </div>

                        <div class="control-group">
                            <label class="control-label">Password:</label>
                            <div class="controls">
                                <input type="password" placeholder="Unesi sifru" name="sifra" class="input-xlarge">
                            </div>
                        </div>

                        <hr>
                        <div class="actions"><input tabindex="9" class="btn btn-inverse large" type="submit" value="Uloguj Se"></div>

                    </fieldset>
                </form>
            </div>

        </div>
        <div class="row center">
            @if(session()->has('UserError'))
                <h4>{{session()->get('UserError')}}</h4>
            @endif
                @if(session()->has('DBEx'))
                    <h4>{{session()->get('DBEx')}}</h4>

                @endif
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

        </div>
    </section>


@endsection
@section("script")
@endsection
