@extends("layout.layout")
@section('content')
    <section class="main-content">
        <div class="row" style=" margin-top: 50px;">
            <div class="span9">
                @foreach($oneproduct as $p)
                    <div class="row">

                        <div class="span4">
                            <img  width="100%"alt="" src="{{asset('/assets/img/'.$p->Slika)}}">

                        </div>
                        <div class="span5">
                            <address>
                                <strong>Nazvi Artikla</strong> <span>{{$p->NazivArtikla}}</span><br>
                                <strong>Vodootpornost:</strong> <span>{{$p->VodoOtp}}</span><br>
                                <strong>Narukvica:</strong> <span>{{$p->NazvNarukvice}}</span><br>
                                <strong>Mehanizam:</strong> <span>{{$p->MehanizamNaziv}}</span><br>
                                <strong>Pol:</strong> <span>{{$p->Pol}}</span><br>
                                <strong>Precnik:</strong> <span>{{$p->Precnik}}</span><br>
                                <strong>Kolekcija:</strong> <span>{{$p->Vrsta}}</span><br>
                            </address>
                            <h4><strong>Cena: {{$p->cena}} din.</strong></h4>
                        </div>

                        <div class="span5">
                            @if(session()->has('korisnik'))
                                <form method="post" action="{{route('order',["id" => $p->ID])}}">
                                    @csrf
                                    <fieldset>
                                        <div class="clearfix">
                                            <label for="name"><span>Ime:</span></label>
                                            <div class="input">
                                                <input tabindex="1" size="18" id="name" name="ime" type="text" value="" class="input-xlarge" placeholder="Unesi ime">
                                            </div>
                                        </div>

                                        <div class="clearfix">
                                            <label for="email"><span>Prezime:</span></label>
                                            <div class="input">
                                                <input tabindex="2" size="25" id="email" name="prezime" type="text" value="" class="input-xlarge" placeholder="Unesi Prezime">
                                            </div>
                                        </div>

                                        <div class="clearfix">
                                            <label for="message"><span>Adresa:</span></label>
                                            <div class="input">
                                                <input tabindex="2" size="25" id="email" name="adresa" type="text" value="" class="input-xlarge" placeholder="Unesi Adresu">
                                            </div>
                                        </div>
                                        <div class="clearfix">
                                            <label for="message"><span>Broj Telefona:</span></label>
                                            <div class="input">
                                                <input tabindex="2" size="25" id="email" name="brojtel" type="text" value="" class="input-xlarge" placeholder="Unesi broj telefona">
                                            </div>
                                        </div>

                                        <div class="actions">
                                            <button tabindex="3" type="submit" class="btn btn-inverse">Poruci</button>
                                        </div>
                                        <div class="row center">
                                            @if ($errors->any())
                                                <div class="alert alert-danger">
                                                    <ul>
                                                        @foreach ($errors->all() as $error)
                                                            <li>{{ $error }}</li>
                                                        @endforeach
                                                    </ul>
                                                </div>
                                            @endif
                                                @if(session()->has('Success'))
                                                    <h4>{{session()->get('Success')}}</h4>

                                                @endif
                                        </div>
                                    </fieldset>
                                </form>
                            @endif
                        </div>
                    </div>
                @endforeach
                <div class="row">


                </div>
            </div>

        </div>
    </section>
@endsection
@section('script')
@endsection
