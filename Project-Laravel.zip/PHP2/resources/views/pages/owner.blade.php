@extends("layout.layout")
@section('content')
    <section class="main-content">
        <div class="row" style="height: 700px;">

            <div class="span9">

                <div class="row">
                    @foreach($owner as $a)
                        <div class="span4">
                            <img  width="100%"alt="" src="{{asset('assets/img/'.$a->slika)}}">

                        </div>
                        <div class="span5">
                            <p>{{$a->ime}}</p>

                        </div>

                        <div class="span5">
                        </div>
                    @endforeach
                    <div class="row">


                    </div>
                </div>

            </div>
    </section>
@endsection
@section("script")
@endsection
