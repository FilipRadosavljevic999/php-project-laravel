@extends('Layout.layout')
@section('content')
    <section class="header_text sub">

        <h4><span>Izmeni Proizvod</span></h4>
    </section>

    <section class="main-content">
        <div class="row">
            <div class="span12 center">

                <form action="{{route("addProduct")}}" method="POST" class="form-stacked" enctype="multipart/form-data">
                    @csrf

                    <div class="control-group">
                        <label class="control-label">Slika</label>
                        <div class="controls">
                            <input type="file" required style="width: 30%"placeholder=" " name="slika"  class="input-xlarge">
                        </div>
                        <div class="control-group">
                            <label class="control-label">Naziv</label>
                            <div class="controls">
                                <input type="text" style="width: 30%" placeholder=" Dodaj Naziv" name="naziv"  class="input-xlarge">
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Cena:</label>
                            <div class="controls">
                                <input type="text" style="width: 30%" placeholder="Dodaj Cenu" name="cena" class="input-xlarge">
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Vodootpornost:</label>
                            <div class="controls">
                                <input type="text" style="width: 30%"placeholder="Dodaj Vodootpornost" name="vodootpornost" class="input-xlarge">
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Narukvica:</label>
                            <div class="controls">

                                <select name="narukvica" style="width: 30%" class="input-xlarge" id="exampleFormControlSelect1">
                                    @foreach($narukvica as $n)
                                        <option value="{{$n->idnarukvica}}">{{$n->naziv}}</option>
                                    @endforeach

                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Mehanizmi:</label>
                            <div class="controls">

                                <select name="mehanizmi" style="width: 30%"class="input-xlarge" id="exampleFormControlSelect1">
                                    @foreach($mehanizam as $m)
                                        <option value="{{$m->idmehanizam}}">{{$m->naziv}}</option>
                                    @endforeach

                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Pol:</label>
                            <div class="controls">

                                <select name="pol"style="width: 30%"id="exampleFormControlSelect1">
                                    @foreach($pol as $pl)
                                        <option value="{{$pl->idpol}}">{{$pl->nazivpola}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Precnik:</label>
                            <div class="controls">

                                <select name="precnik" style="width: 30%"class="input-xlarge" id="exampleFormControlSelect1">
                                    @foreach($precnik as $pr)
                                        <option value="{{$pr->idprecnik}}">{{$pr->velicina}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="control-group">

                            <label class="control-label">Vrsta:</label>
                            <div class="controls">

                                <select name="vrsta" style="width: 30%"class="input-xlarge" id="exampleFormControlSelect1">
                                    @foreach($vrsta as $v)
                                        <option value="{{$v->idvrsta}}">{{$v->vrstanaziv}}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="control-group">


                        </div>
                        <div class="actions"><input tabindex="9" class="btn btn-inverse large" type="submit" value="Dodaj Proizvod"></div>
                        <div class="control-group">
                            @if ($errors->any())
                                <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            @if(session()->has('uspelo'))
                                <p>{{session()->get('uspelo')}}</p>

                            @endif
                        </div>



                </form>
            </div>
        </div>
    </section>
@endsection



