@extends("layout.layout")
@section("content")
    <section class="main-content">
        <div class="row" style="height: 700px;">
            <div class="span5">

            </div>
            <div class="span7">

                <form action="{{route('send')}}" method="post">
                    @csrf
                    <div class="clearfix">
                        <label for="message"><span>Poruka:</span></label>
                        <div class="input">
                            <textarea tabindex="3" class="input-xlarge" id="message" name="poruka" rows="7" placeholder="Poruka"></textarea>
                        </div>
                    </div>

                    <div class="actions">
                        <button tabindex="3" type="submit" class="btn btn-inverse">Posalji poruku</button>
                    </div>
                    <div class="clearfix">
                        @if(session()->has('Poslata'))
                            <p>{{session()->get('Poslata')}}</p>
                        @endif
                    </div>

                </form>
            </div>
        </div>
    </section>
@endsection
@section("script")
@endsection
