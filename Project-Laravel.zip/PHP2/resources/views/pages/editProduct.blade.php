@extends('Layout.layout')
@section('content')
    <section class="main-content">
        <div class="row">
            <div class="span9 center" >
                @foreach($proizvod as $p)
                <form action="{{route("eProduct",["id"=>$p->ID])}}" method="POST" class="form-stacked" style="margin-top: 50px;">
                    @csrf


                        <div class="control-group" >
                            <label class="control-label">Naziv</label>
                            <div class="controls">
                                <input type="text" style="width: 30%" placeholder=" Izmeni Naziv" name="naziv" value="{{$p->NazivArtikla}}" class="input-xlarge">
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Cena:</label>
                            <div class="controls">
                                <input type="text" style="width: 30%" placeholder="Izmeni Cenu" value='{{$p->cena}}'name="cena" class="input-xlarge">
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Vodootpornost:</label>
                            <div class="controls">
                                <input type="text" style="width: 30%" placeholder="Izmeni Vodootpornost" value='{{$p->VodoOtp}}'name="vodootpornost" class="input-xlarge">
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Narukvica:</label>
                            <div class="controls">

                                <select name="narukvica" style="width:30%;">
                                    @foreach($narukvica as $n)
                                        <option  value="{{$n->idnarukvica}}">{{$n->naziv}}</option>
                                    @endforeach

                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Mehanizmi:</label>
                            <div class="controls">

                                <select name="mehanizmi"class="input-xlarge" style="width: 30%" id="exampleFormControlSelect1">
                                    @foreach($mehanizam as $m)
                                        <option value="{{$m->idmehanizam}}">{{$m->naziv}}</option>
                                    @endforeach

                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Pol:</label>
                            <div class="controls">

                                <select name="pol"class="input-xlarge" style="width: 30%" id="exampleFormControlSelect1">
                                    @foreach($pol as $pl)
                                        <option value="{{$pl->idpol}}">{{$pl->nazivpola}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Precnik:</label>
                            <div class="controls">

                                <select name="precnik"class="input-xlarge" style="width: 30%"style="width: 30%" id="exampleFormControlSelect1">
                                    @foreach($precnik as $pr)
                                        <option value="{{$pr->idprecnik}}">{{$pr->velicina}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="control-group">

                            <label class="control-label">Vrsta:</label>
                            <div class="controls">

                                <select name="vrsta"class="input-xlarge" style="width: 30%" id="exampleFormControlSelect1">
                                    @foreach($vrsta as $v)
                                        <option value="{{$v->idvrsta}}">{{$v->vrstanaziv}}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="control-group">

                            <div class="controls">
                                <input type="hidden"  placeholder="Izmeni Naziv" name="id" value="{{$p->ID}}" class="input-xlarge">
                            </div>
                        </div>
                        <div class="actions"><input tabindex="9" class="btn btn-inverse large" type="submit" value="Izmeni Artikl"></div>
                        <div class="control-group">
                            @if ($errors->any())
                                <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            @if(session()->has('uspelo'))
                                <p>{{session()->get('uspelo')}}</p>

                            @endif

                        </div>
                </form>
                    @endforeach

            </div>
        </div>
    </section>
@endsection
@section("script")
@endsection
