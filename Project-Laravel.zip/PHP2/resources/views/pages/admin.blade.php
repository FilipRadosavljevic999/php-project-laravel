@extends('layout.layout')
@section('content')
    <section class="main-content">
        <div class="row">
            <div class="span9 center">
                <h2 class="title "><span class="text"><strong>Proizvodi</strong></span></h2>
                <table class="table table-striped table-bordered" style="border: 1px solid #0e0e0e">
                    <thead>
                    <tr>
                        <th>Redni broj</th>
                        <th>Slika</th>
                        <th>Naziv</th>
                        <th>Cena</th>
                        <th>Obrisi</th>
                        <th>Izmeni</th>
                        <th>Dodaj</th>

                    </tr>
                    </thead>
                    <tbody>
                    @php
                        $br=1;
                    @endphp
                    @foreach($products as $p)
                        <tr>

                            <td>{{$br++}}</td>
                            <td width="50%"  ><a href="{{route('oneproduct',["id"=>$p->ID])}}" width="100%" height="70px" >
                                    <img alt="" width="50%" height="50px" src="{{asset("assets/img/".$p->Slika)}}">
                                </a></td>
                            <td>{{$p->NazivArtikla}}</td>
                            <td>{{$p->cena}} din</td>
                            <td><a href="{{route("deleteProduct",["id"=>$p->ID])}}">Obrisi Proizvod</a></td>
                            <td><a href="{{route("editProduct",["id"=>$p->ID])}}">Izmeni Proizvod</a></td>
                             <td><a href="{{route("showAddProduct")}}">Dodaj Proizvod</a></td>
                        </tr>
                    @endforeach


                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td></td>
                    </tr>
                    </tbody>
                </table>


            </div>
            <div class="span3 col">

            </div>
        </div>
        <div class="row">

            <div class="span10 center">
                <h2 class="title "><span class="text"><strong>Korisnici</strong></span></h2>
                <table class="table table-striped table-bordered" width="100%" style="border: 1px solid #0e0e0e">
                    <thead>
                    <tr>
                        <th >Redni broj</th>
                        <th>Ime</th>
                        <th>Prezime</th>
                        <th>Email</th>
                        <th>Obrisi</th>


                    </tr>
                    </thead>
                    <tbody>
                    @php
                        $br=1;
                    @endphp

                    @foreach($korisnici as $k)
                        <tr style="border: 1px solid #0e0e0e">

                            <td>{{$br++}}</td>
                            <td width="50%"  >{{$k->ime}}</td>
                            <td>{{$k->prezime}}</td>
                            <td>{{$k->email}} </td>
                            <td><a href="{{route("removeUser",['id'=>$k->idkorisnik])}}">Obrisi Korisnika</a></td>

                        </tr>
                    @endforeach


                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td></td>
                    </tr>
                    </tbody>
                </table>


            </div>
            <div class="span3 col">

            </div>
        </div>
        <div class="row">

            <div class="span10 center">
                <h2 class="title "><span class="text"><strong>Porudzbine</strong></span></h2>

                <table class="table table-striped table-bordered" width="100%" style="border: 1px solid #0e0e0e">
                    <thead>
                    <tr>
                        <th>Redni broj</th>
                        <th>Ime</th>
                        <th>Prezime</th>
                        <th>Adresa</th>
                        <th>Broj Telefona</th>
                        <th>Obrisi Porudzbinu</th>


                    </tr>
                    </thead>
                    <tbody>
                    @php
                        $br=1;
                    @endphp
                    @foreach($porudzbina as $pr)
                        <tr>

                            <td>{{$br++}}</td>
                            <td width="50%"  >{{$pr->ime}}</td>
                            <td>{{$pr->prezime}}</td>
                            <td>{{$pr->adresa}} </td>
                            <td>{{$pr->brojtelefona}} din</td>
                            <td><a href="{{route("deleteOrder",["id"=>$pr->idporudzbina])}}">Obrisi Porudzbinu</a></td>

                        </tr>
                    @endforeach


                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td></td>
                    </tr>
                    </tbody>
                </table>


            </div>
            <div class="span3 col">

            </div>
        </div>
         <div class="row">

            <div class="span10 center">
                <h2 class="title "><span class="text"><strong>Poruke</strong></span></h2>
                <table class="table table-striped   table-bordered" width="100%" style="border: 1px solid #0e0e0e">
                    <thead>
                    <tr>
                        <th>Redni Br.</th>
                        <th>Email</th>
                        <th>Poruka</th>
                        <th>Obrisi poruku</th>
                    </tr>
                    </thead>
                    <tbody>
                    @php
                        $br=1;
                    @endphp

                    @foreach($poruke as $pe)
                        <tr>
                            <td>{{$br++}}</td>
                            <td>{{$pe->email}}</td>
                            <td>{{$pe->poruka}} </td>
                            <td>{{$pe->poruka}} </td>
                            <td><a href="{{route('removeMessage',['id'=>$pe->idPoruke])}}">Obrisi poruku</a></td>
                        </tr>
                    @endforeach
                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td></td>
                    </tr>
                    </tbody>
                </table>


            </div>
            <div class="span3 col">

            </div>
        </div>
    </section>
@endsection
@section('script')
@endsection
