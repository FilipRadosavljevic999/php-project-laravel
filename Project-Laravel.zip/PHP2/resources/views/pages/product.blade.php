@extends("layout.layout")
@section('content')
    <section class="main-content">

        <div class="row">
            <div class="span9">
                <div width="100%">
                    <ul class="thumbnails listing-products">

                            @forelse($products as $p)
                                @include('partial.partialProduct')
                            @empty
                                <h2>No products.</h2>
                            @endforelse
                    </ul>


                </div>
            </div>
            <div class="span3 col">
                <br/>
                <div class="block">
                    <form action="/" method="GET">

                        <div class="row">
                            <h3>Pretraga</h3>
                            <div class="col-md-2">
                                <input type="text" name="rec" placeholder="Unesi slova"  class="form-control"
                                       @if($rec=="") value="{{$rec}}"@endif>
                            </div>
                            <div class="col-md-2">
                                <input type="submit" placeholder="Pretrazi" value="Pretrazi" class="btn btn-primary">
                            </div>
                        </div>
                    </form>
                </div>


            </div>
        </div>
        </div>
        <div class="row center ">

                {{$products->links()}}




        </div>



    </section>
@endsection
@section('script')
@endsection
