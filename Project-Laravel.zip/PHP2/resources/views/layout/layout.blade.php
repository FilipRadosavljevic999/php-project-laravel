<!DOCTYPE html>
<html lang="en">
@include('fixed.head')
<body>
<div id="wrapper" class="container">
    @include('fixed.menu')
    @yield('content')
    @include('fixed.footer')
</div>
@include('fixed.script')
@yield('script')
</body>
</html>
