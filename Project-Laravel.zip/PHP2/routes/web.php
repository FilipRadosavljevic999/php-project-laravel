<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [\App\Http\Controllers\ProductController::class,"index"])->name("/");
Route::get("/oneproduct/{id}",[\App\Http\Controllers\ProductController::class,"show"])->name('oneproduct');
Route::get("/auth",[\App\Http\Controllers\AuthController::class,"index"])->name('auth');
Route::get("/autor",[\App\Http\Controllers\OwnerController::class,"index"])->name('autor');
Route::post("/send",[\App\Http\Controllers\ContactController::class,"AddMessage"])->name('send');
Route::middleware([\App\Http\Middleware\NoAuthMiddleware::class])->group(function () {
    Route::post("/register",[\App\Http\Controllers\AuthController::class,"register"])->name('register');
    Route::post("/login",[\App\Http\Controllers\AuthController::class,"login"])->name('login');
});

Route::middleware([\App\Http\Middleware\IsAuthMiddleware::class])->group(function () {
    Route::get("/kontakt",[\App\Http\Controllers\ContactController::class,"index"])->name('kontakt');

    Route::get("/logout",[\App\Http\Controllers\AuthController::class,"logout"])->name('logout');
    Route::post("/order/{id}",[\App\Http\Controllers\OrderController::class,"Order"])->name('order');
});

Route::middleware([\App\Http\Middleware\IsAdminMiddleware::class])->group(function () {
    Route::get("/admin",[\App\Http\Controllers\AdminController::class,"index"])->name('admin');
    Route::get("/deleteProduct/{id}",[\App\Http\Controllers\AdminController::class,"deleteProduct"])->name('deleteProduct');
    Route::get("/editProduct/{id}",[\App\Http\Controllers\AdminController::class,"showEdit"])->name('editProduct');
    Route::post("/eProduct/{id}",[\App\Http\Controllers\AdminController::class,"editProduct"])->name('eProduct');
    Route::get("/showAddProduct",[\App\Http\Controllers\AdminController::class,"showAddProduct"])->name('showAddProduct');
    Route::post("/addProduct",[\App\Http\Controllers\AdminController::class,"addProduct"])->name('addProduct');
    Route::get("/removeUser/{id}",[\App\Http\Controllers\AdminController::class,"removeUser"])->name('removeUser');
    Route::get("/deleteOrder/{id}",[\App\Http\Controllers\AdminController::class,"deleteOrder"])->name('deleteOrder');
    Route::get("/removeMessage/{id}",[\App\Http\Controllers\AdminController::class,"deleteMessage"])->name('removeMessage');
});

