<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class OrderModel extends Model
{
    use HasFactory;
    public function doOrder($ime,$prezime,$adresa,$idKorisnik,$idArtikl,$brojtelefona){
        return DB::table('porudzbina')
            ->insert([
                ['idartikl'=>$idArtikl,
                    'idkorisnik'=>$idKorisnik,
                    'ime'=>$ime,
                    'prezime'=>$prezime,
                    'adresa'=>$adresa,
                    'brojtelefona'=>$brojtelefona,
                    'Deleted'=>1]


            ]);
    }
}
