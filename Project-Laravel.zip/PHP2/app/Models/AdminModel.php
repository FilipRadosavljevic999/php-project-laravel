<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class AdminModel extends Model
{
    use HasFactory;
    public function getProductsAdmin(){
        $rezultat=DB::table("artikl")
            ->select("artikl.naziv AS NazivArtikla","artikl.vecaslika AS Slika","cenovnik.cena AS cena","artikl.idartikl AS ID")
            ->join("cenovnik","artikl.idartikl","=","cenovnik.idartikl")
            ->where(
                [
                    ["cenovnik.aktivna","=",1],
                    ["artikl.kolicina",">",0]
                ]
            )

            ->orderBy("artikl.idartikl","desc")
            ->get();
        return $rezultat;
    }
    public function doDeleteProduct($id){
        return DB::table('artikl')->
        where('idartikl','=',$id)
            ->update(
                ['kolicina'=>0]
            );
    }
    public function getAllTypes(){
        return DB::table('vrsta')->get();
    }
    public function getAllMechanisms(){
        return DB::table('mehanizam')->get();
    }
    public function getAllCaseDiametre(){
        return DB::table('precnik')->get();
    }
    public function getAllStrap(){
        return DB::table('narukvica')->get();
    }
    public function getAllGender(){
        return DB::table('pol')->get();
    }
    public function doEditProduct($id,$naziv,$vodootpornost,$narukvica,$mehanizmi,$pol,$precnik,$vrsta){
        return DB::table('artikl')->where('idartikl',"=",$id)
            ->update(
                [
                    "naziv"=>$naziv,
                    "vodootpornost"=>$vodootpornost,
                    "idnarukvica"=>$narukvica,
                    "idmehanizam"=>$mehanizmi,
                    "idpol"=>$pol,
                    "idprecnik"=>$precnik,
                    "idvrsta"=>$vrsta
                ]
            );

    }
    public function doEditPrice($id,$cena){
        return DB::table('cenovnik')
            ->where([
                ['idartikl',"=",$id],
                ['aktivna',"=",1]
            ])
            ->update(
                [
                    "cena"=>$cena
                ]
            );
    }
    public function doAddProduct($putanja,$naziv,$vodootpornost,$narukvica,$mehanizmi,$pol,$precnik,$vrsta){
        return DB::table('artikl')
            ->insertGetId(
                [
                    'naziv'=>$naziv,
                    'vecaslika'=>$putanja,
                    'kolicina'=>50,
                    "vodootpornost"=>$vodootpornost,
                    "idnarukvica"=>$narukvica,
                    "idmehanizam"=>$mehanizmi,
                    "idpol"=>$pol,
                    "idprecnik"=>$precnik,
                    "idvrsta"=>$vrsta
                ]
            );
    }
    public function doAddPrice($id,$cena){
        return DB::table('cenovnik')
            ->insert([
                'cena'=>$cena,
                'datumod'=>'2020-12-6',
                'datumdo'=>null,
                'aktivna'=>1,
                'idartikl'=>$id
            ]);



    }
    public function getAllUser(){
        return DB::table('korisnici')
            ->where('aktivan','=',1)
            ->get();



    }
    public function doRemoveUser($id){
        return DB::table('korisnici')->
        where('idkorisnik','=',$id)
            ->update(
                ['aktivan'=>0]
            );
    }
    public function getAllOrder(){
        return DB::table('porudzbina')->where('Deleted','=',1)->get();
    }
    public function doDeleteOrder($id){
        return DB::table('porudzbina')->
        where('idporudzbina','=',$id)
            ->update(
                ['Deleted'=>0]
            );
    }
}
