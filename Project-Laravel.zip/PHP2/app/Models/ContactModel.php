<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ContactModel extends Model
{
    use HasFactory;
    public function AddMessage($id,$poruka){
        try {
            return DB::table("poruke")->insert([
                'idKorisnik'=>$id,
                'Poruka'=>$poruka

            ]);
        }catch (\PDOException $ex){

        }

    }
    public function getAllMessage(){
        return DB::table("poruke")
            ->select('korisnici.email AS email','poruke.Poruka as poruka','poruke.idPoruke')
            ->join('korisnici','poruke.idKorisnik','=','korisnici.idkorisnik')
            ->where('poruke.Deleted',"=",1)
            ->get();
    }
    public function doDeleteMessage($id){
        return DB::table('poruke')->
        where('idPoruke','=',$id)
            ->update(
                ['Deleted'=>0]
            );
    }
}
