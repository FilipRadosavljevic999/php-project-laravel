<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ProductModel extends Model
{
    use HasFactory;
    public function getProducts(){
        $rezultat=DB::table("artikl")
            ->select("artikl.naziv AS NazivArtikla","artikl.vecaslika AS Slika","cenovnik.cena AS cena","artikl.idartikl AS ID")
            ->join("cenovnik","artikl.idartikl","=","cenovnik.idartikl")
            ->where(
                [
                    ["cenovnik.aktivna","=",1],
                    ["artikl.kolicina",">",0]
                ]
            )

            ->orderBy("artikl.idartikl","desc")
            ->paginate(6);
            return $rezultat;
    }
    public function filterProducts($id){
        $rezultat=DB::table("artikl")
            ->select("artikl.naziv AS NazivArtikla","artikl.vecaslika AS Slika","cenovnik.cena AS cena","artikl.idartikl AS ID")
            ->join("cenovnik","artikl.idartikl","=","cenovnik.idartikl")
            ->where(
                [
                    ["cenovnik.aktivna","=",1],
                    ["artikl.kolicina",">",0],
                    ["artikl.naziv","like","%".$id."%"]
                ]
            )

            ->orderBy("artikl.idartikl","desc")
            ->paginate(6);
        return $rezultat;
    }
    public function getOneProduct($id)
    {
        $rezultat=DB::table("artikl")
            ->select("artikl.naziv AS NazivArtikla",
                "artikl.vecaslika AS Slika",
                "cenovnik.cena AS cena","artikl.idartikl AS ID",
                "artikl.vodootpornost AS VodoOtp",
                "narukvica.naziv AS NazvNarukvice",
                "mehanizam.naziv AS MehanizamNaziv",
                "pol.nazivpola AS Pol",
                "precnik.velicina AS Precnik",
                "vrsta.vrstanaziv AS Vrsta"

            )
            ->join("cenovnik","artikl.idartikl","=","cenovnik.idartikl")
            ->join("narukvica","artikl.idnarukvica","=","narukvica.idnarukvica")
            ->join("mehanizam","artikl.idmehanizam","=","mehanizam.idmehanizam")
            ->join("pol","artikl.idpol","=","pol.idpol")
            ->join("precnik","artikl.idprecnik","=","precnik.idprecnik")
            ->join("vrsta","artikl.idvrsta","=","vrsta.idvrsta")
            ->where(
                [
                    ["cenovnik.aktivna","=",1],
                    ["artikl.kolicina",">",0],
                    ["artikl.idartikl","=",$id]
                ]
            )
            ->orderBy("artikl.idartikl","desc")
            ->get();
        return $rezultat;
    }
}
