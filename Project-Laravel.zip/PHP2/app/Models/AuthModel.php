<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Mosquitto\Exception;

class AuthModel extends Model
{
    use HasFactory;
    public function doRegister($ime,$prezime,$email,$sifra){
        try {
            return DB::table('korisnici')->insert([
                [   "ime"=>$ime,
                    "prezime"=>$prezime,
                    "email"=>$email,
                    "sifra"=>$sifra,
                    "aktivan"=>1,
                    "iduloga"=>2],

            ]);
        }
        catch (\PDOException $ex){
            return false;
        }


    }
    public function doLogin($email,$password){

        try {
            return  DB::table("korisnici")
                ->join("uloga", "korisnici.iduloga", "=", "uloga.id")
                ->where("email", "=", $email)
                ->where("sifra", "=", $password)
                ->first();

        }
        catch (\PDOException $ex)
        {
            return false;

        }

    }
}
