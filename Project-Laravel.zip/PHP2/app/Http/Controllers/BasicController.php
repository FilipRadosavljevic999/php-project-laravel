<?php

namespace App\Http\Controllers;

use App\Models\MenuModel;
use Illuminate\Http\Request;

class BasicController extends Controller
{
    protected $data;

    public function __construct(){
        $meni=new MenuModel();
        $this->data['data']=$meni->getMenu();



    }
}
