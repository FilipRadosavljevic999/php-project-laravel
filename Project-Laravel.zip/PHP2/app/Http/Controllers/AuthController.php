<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use App\Models\AuthModel;
use Illuminate\Http\Request;

class AuthController extends BasicController
{
    public function index(){
        return view("pages.register",$this->data);
    }
    public function register(RegisterRequest $request){
        $ime=$request->ime;
        $prezime=$request->prezime;
        $email=$request->email;
        $sifra=md5($request->sifra);
        $korisni=new AuthModel();
        $unos=$korisni->doRegister($ime,$prezime,$email,$sifra);
        if($unos==false){
            $request->session()->put("DBEx","Vec postoji korisnik sa tim emailom");
        }
        else{
            $request->session()->put("DBEx","Uspesno ste se registrovali");
        }
        return redirect()->back();
    }
    public function login(LoginRequest $request)
    {

        $email = $request->input("email");
        $password = md5($request->input("sifra"));

        $korisnici=new AuthModel();
        $korisnik=$korisnici->doLogin($email,$password);

        if($korisnik){
            $request->session()->put("korisnik", $korisnik);

            return redirect()->route("/");
        }
        else{
            return redirect()->route("auth")->with('UserError',"Ne postoji korisnik");

        }



    }
    public function logout(Request $request){
        $request->session()->remove("korisnik");
        return redirect()->route("/");
    }
}
