<?php

namespace App\Http\Controllers;

use App\Models\ProductModel;
use Illuminate\Http\Request;

class ProductController extends BasicController
{
    public function index(Request $request)
    {
        //dd($request->session()->get('korisnik'));
        $proizvodi= new ProductModel();
        $this->data['rec']="";
        if($request->has('rec')){
            $this->data['rec']=$request->get('rec');
            $this->data['products']=$proizvodi->filterProducts($request->get("rec"));
        }
        else{
            $this->data['products']=$proizvodi->getProducts();
        }

        return view('pages.product',$this->data,);
    }
    public function show($id){
        {
            $proizvodi=new ProductModel();
            $this->data['oneproduct']=$proizvodi->getOneProduct($id);
            return view("pages.oneproduct",$this->data);
        }
    }
}
