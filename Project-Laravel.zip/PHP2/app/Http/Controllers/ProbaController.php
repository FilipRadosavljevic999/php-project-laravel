<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProbaController extends BasicController
{
    public function index(){
        return view('pages.proba',["data"=>$this->data]);
    }
}
