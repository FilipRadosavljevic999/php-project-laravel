<?php

namespace App\Http\Controllers;

use App\Models\OwnerModel;
use Illuminate\Http\Request;

class OwnerController extends BasicController
{
    public function index(){
        $owner=new OwnerModel();
        $this->data['owner']=$owner->getOwner();
        return view("pages.owner",$this->data);
    }
}
