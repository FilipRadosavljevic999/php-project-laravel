<?php

namespace App\Http\Controllers;

use App\Http\Requests\EditProductRequest;
use App\Models\AdminModel;
use App\Models\ContactModel;
use App\Models\ProductModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends BasicController
{
    public function index(){
        $instanca=new AdminModel();
        $instancaMessage=new ContactModel();
        $this->data["products"]=$instanca->getProductsAdmin();
        $this->data["korisnici"]=$instanca->getAllUser();
        $this->data["porudzbina"]=$instanca->getAllOrder();
        $this->data["poruke"]=$instancaMessage->getAllMessage();
        return view("pages.admin",$this->data);
    }
    public function deleteProduct($id){
       $instanca=new AdminModel();
       $delete=$instanca->doDeleteProduct($id);
       return redirect()->back();
    }
    public function showEdit($id){

        $instanca=new AdminModel();
        $instancaProduct=new ProductModel();
        $this->data['vrsta']=$instanca->getAllTypes();
        $this->data['precnik']=$instanca->getAllCaseDiametre();
        $this->data['narukvica']=$instanca->getAllStrap();
        $this->data['pol']=$instanca->getAllGender();
        $this->data['mehanizam']=$instanca->getAllMechanisms();
        $this->data['proizvod']=$instancaProduct->getOneProduct($id);
        return view("pages.editProduct",$this->data);

    }
    public function editProduct($id,EditProductRequest $request)
    {
        $naziv=$request->naziv;
        $cena=$request->cena;
        $vodootpornost=$request->vodootpornost;
        $narukvica=$request->narukvica;
        $mehanizmi=$request->mehanizmi;
        $pol=$request->pol;
        $precnik=$request->precnik;
        $vrsta=$request->vrsta;
        $id=$request->id;
        $proizvod=new AdminModel();
        $proizvodizmenjen=$proizvod->doEditProduct($id,$naziv,$vodootpornost,$narukvica,$mehanizmi,$pol,$precnik,$vrsta);
        $cena=$proizvod->doEditPrice($id,$cena);
        return redirect()->back()->with('uspelo', 'Proizvod je izmenjen');
    }
    public function showAddProduct(){
        $instanca=new AdminModel();
        $this->data['vrsta']=$instanca->getAllTypes();
        $this->data['precnik']=$instanca->getAllCaseDiametre();
        $this->data['narukvica']=$instanca->getAllStrap();
        $this->data['pol']=$instanca->getAllGender();
        $this->data['mehanizam']=$instanca->getAllMechanisms();
        return view("pages.addProduct",$this->data);

    }
    public function addProduct(EditProductRequest $request){
        $instanca=new AdminModel();
        $naziv=$request->naziv;
        $cena=$request->cena;
        $vodootpornost=$request->vodootpornost;
        $narukvica=$request->narukvica;
        $mehanizmi=$request->mehanizmi;
        $pol=$request->pol;
        /*$newName = time() . $picture->getClientOriginalName();
        $picture->move(public_path() . '/images/movies/', $newName);*/
        $precnik=$request->precnik;
        $vrsta=$request->vrsta;
        $slika = $request->file("slika");
        $novoime=time().$slika->getClientOriginalName();
        $slika->move(public_path().'/assets/img/',$novoime);
        $idnovog=$instanca->doAddProduct($novoime,$naziv,$vodootpornost,$narukvica,$mehanizmi,$pol,$precnik,$vrsta);
        $cenovnik=$instanca->doAddPrice($idnovog,$cena);
        return redirect()->back()->with('uspelo', 'Proizvod je dodat');

    }
    public function removeUser($id){
        $instanca=new AdminModel();
        $obrisani=$instanca->doRemoveUser($id);
        return redirect()->back();
    }
    public function deleteOrder($id){
        $instanca=new AdminModel();
        $obrisani=$instanca->doDeleteOrder($id);
        return redirect()->back();

    }
    public function deleteMessage($id){
        $poruke=new ContactModel();
        $obrisano=$poruke->doDeleteMessage($id);
        return redirect()->back();
    }
}
