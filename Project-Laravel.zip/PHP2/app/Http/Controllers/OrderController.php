<?php

namespace App\Http\Controllers;

use App\Http\Requests\OrderRequest;
use App\Models\OrderModel;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function Order($id,OrderRequest $request){
        $porudzbina=new OrderModel();
        $vremeunosa=date("Y-d-m",time());
        $korisnik=$request->session()->get('korisnik');
        $idkorisnik=$korisnik->idkorisnik;
        $rezultat = $porudzbina->doOrder($request->ime, $request->prezime, $request->adresa, $idkorisnik,
            $id, $request->brojtel);
        return redirect()->back()->with("Success","Uspesno ste porucili");
    }
}
