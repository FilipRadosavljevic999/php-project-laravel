<?php

namespace App\Http\Controllers;

use App\Models\ContactModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ContactController extends BasicController
{
    public function index(){
        return view('pages.contact',$this->data);
    }
    public function AddMessage(Request $request){
        $korisnik=$request->session()->get('korisnik');
        $id=$korisnik->idkorisnik;
        $poruka=$request->poruka;
        $poruka=new ContactModel();
        $rezultat=$poruka->AddMessage($id,$poruka);
        return redirect()->back()->with('Poslata',"Poruka je uspesno poslata");
    }

}
