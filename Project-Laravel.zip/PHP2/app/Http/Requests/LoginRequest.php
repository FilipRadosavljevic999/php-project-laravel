<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class LoginRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            "email"=>"required|email|min:10|max:50",
            "sifra" => 'required|min:6'
        ];
    }
    public function messages()
    {
        return [
            "email.required" => "Polje za email je obavezno.",
            "email.email" => "Mora biti unesen email",
            "email.min" => "Email mora sadrzati vise od 10 karaktera",
            "email.max" => "Email mora sadrzati manje od 1=50 karaktera",
            "sifra.required" => "Sifra je obavezna.",
            "sifra.min" => "Sifra mora sadrzati vise od 6 karaktera"
        ];
    }
}
