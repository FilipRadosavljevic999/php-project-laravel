<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class OrderRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            "ime"=>"required|min:3|max:15",
            "prezime"=>"required|min:3|max:15",
            "adresa"=>"required|min:3|max:15"
        ];
    }
    public function messages()
    {
        return [
            "ime.required"=>"Ime je obavezno",
            "ime.min"=>"Ime mora sadrzati najmanje 3 slova",
            "ime.max"=>"Ime mora sadrzati najvise 15 slova",
            "prezime.required"=>"Prezime je obavezno",
            "prezime.min"=>"Prezime mora sadrzati najmanje 3 slova",
            "prezime.max"=>"Prezime mora sadrzati najvise 15 slova",
            "adresa.required"=>"Adresa je obavezna",
            "adresa.min"=>"Adresa mora sadrzati najmanje 3 slova",
            "adresa.max"=>"Adresa mora sadrzati najvise 15 slova",
        ];
    }
}
