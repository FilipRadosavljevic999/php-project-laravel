<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EditProductRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'naziv'=>'required|min:3|max:15',
            'cena'=>'required|numeric',
            'vodootpornost'=>'required|min:3|max:15'
        ];
    }
    public function messages()
    {
        return [
            "naziv.required" => "Polje za naziv proizvoda je obavezno.",
            "naziv.min" => "Minimalan broj karaktera za naziv je 3.",
            "naziv.max" => "Maksimalan broj karaktera za naziv je 15 ",
            "cena.required" => "Polje za cenu je obavezno.",
            "cena.numeric" => "Polje za cenu mora biti broj",
            "vodootpornost.required" => "Polje za vodootpornost  je obavezno.",
            "vodootpornost.min" => "Minimalan broj slova za vodootpornost  je 3.",
            "vodootpornost.max" => "Maksimalan broj slova za vodootpornost  je 15."

        ];
    }
}
